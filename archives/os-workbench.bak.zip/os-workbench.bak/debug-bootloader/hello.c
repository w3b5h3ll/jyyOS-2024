#include <am.h>
#include <klib.h>

int main() {
    printf("Hello, OS World\n");
}
